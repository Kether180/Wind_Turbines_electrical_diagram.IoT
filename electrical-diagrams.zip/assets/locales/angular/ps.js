/**
 * @license
 * Copyright Google Inc. All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
(function (factory) {
    if (typeof module === "object" && typeof module.exports === "object") {
        var v = factory(null, exports);
        if (v !== undefined) module.exports = v;
    }
    else if (typeof define === "function" && define.amd) {
        define("@angular/common/locales/ps", ["require", "exports"], factory);
    }
})(function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    // THIS CODE IS GENERATED - DO NOT MODIFY
    // See angular/tools/gulp-tasks/cldr/extract.js
    var u = undefined;
    function plural(n) {
        if (n === 1)
            return 1;
        return 5;
    }
    exports.default = [
        'ps', [['غ.م.', 'غ.و.'], u, u], u,
        [
            ['S', 'M', 'T', 'W', 'T', 'F', 'S'],
            ['يونۍ', 'دونۍ', 'درېنۍ', 'څلرنۍ', 'پينځنۍ', 'جمعه', 'اونۍ'], u,
            u
        ],
        u,
        [
            ['ج', 'ف', 'م', 'ا', 'م', 'ج', 'ج', 'ا', 'س', 'ا', 'ن', 'د'],
            [
                'جنوري', 'فبروري', 'مارچ', 'اپریل', 'مۍ', 'جون', 'جولای',
                'اگست', 'سېپتمبر', 'اکتوبر', 'نومبر', 'دسمبر'
            ],
            u
        ],
        [
            ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'],
            [
                'جنوري', 'فبروري', 'مارچ', 'اپریل', 'مۍ', 'جون', 'جولای',
                'اگست', 'سپتمبر', 'اکتوبر', 'نومبر', 'دسمبر'
            ],
            [
                'جنوري', 'فېبروري', 'مارچ', 'اپریل', 'مۍ', 'جون', 'جولای',
                'اگست', 'سپتمبر', 'اکتوبر', 'نومبر', 'دسمبر'
            ]
        ],
        [
            ['له میلاد وړاندې', 'م.'], u,
            ['له میلاد څخه وړاندې', 'له میلاد څخه وروسته']
        ],
        6, [4, 5], ['y/M/d', 'y MMM d', 'د y د MMMM d', 'EEEE د y د MMMM d'],
        ['H:mm', 'H:mm:ss', 'H:mm:ss (z)', 'H:mm:ss (zzzz)'], ['{1} {0}', u, u, u],
        [',', '.', ';', '%', '\u200e+', '\u200e−', 'E', '×', '‰', '∞', 'NaN', ':'],
        ['#,##0.###', '#,##0%', '#,##0.00 ¤', '#E0'], '؋', 'افغانۍ',
        { 'AFN': ['؋'], 'JPY': ['JP¥', '¥'], 'USD': ['US$', '$'] }, plural
    ];
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9wYWNrYWdlcy9jb21tb24vbG9jYWxlcy9wcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7O0dBTUc7Ozs7Ozs7Ozs7OztJQUVILHlDQUF5QztJQUN6QywrQ0FBK0M7SUFFL0MsSUFBTSxDQUFDLEdBQUcsU0FBUyxDQUFDO0lBRXBCLFNBQVMsTUFBTSxDQUFDLENBQVM7UUFDdkIsSUFBSSxDQUFDLEtBQUssQ0FBQztZQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ3RCLE9BQU8sQ0FBQyxDQUFDO0lBQ1gsQ0FBQztJQUVELGtCQUFlO1FBQ2IsSUFBSSxFQUFFLENBQUMsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUM7UUFDakM7WUFDRSxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQztZQUNuQyxDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFLE1BQU0sQ0FBQyxFQUFFLENBQUM7WUFDL0QsQ0FBQztTQUNGO1FBQ0QsQ0FBQztRQUNEO1lBQ0UsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQztZQUM1RDtnQkFDRSxPQUFPLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxPQUFPO2dCQUN4RCxNQUFNLEVBQUUsU0FBUyxFQUFFLFFBQVEsRUFBRSxPQUFPLEVBQUUsT0FBTzthQUM5QztZQUNELENBQUM7U0FDRjtRQUNEO1lBQ0UsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQztZQUMvRDtnQkFDRSxPQUFPLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxPQUFPO2dCQUN4RCxNQUFNLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxPQUFPLEVBQUUsT0FBTzthQUM3QztZQUNEO2dCQUNFLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLE9BQU87Z0JBQ3pELE1BQU0sRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLE9BQU8sRUFBRSxPQUFPO2FBQzdDO1NBQ0Y7UUFDRDtZQUNFLENBQUMsaUJBQWlCLEVBQUUsSUFBSSxDQUFDLEVBQUUsQ0FBQztZQUM1QixDQUFDLHFCQUFxQixFQUFFLHFCQUFxQixDQUFDO1NBQy9DO1FBQ0QsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRSxjQUFjLEVBQUUsbUJBQW1CLENBQUM7UUFDcEUsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLGFBQWEsRUFBRSxnQkFBZ0IsQ0FBQyxFQUFFLENBQUMsU0FBUyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQzFFLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEtBQUssRUFBRSxHQUFHLENBQUM7UUFDMUUsQ0FBQyxXQUFXLEVBQUUsUUFBUSxFQUFFLFlBQVksRUFBRSxLQUFLLENBQUMsRUFBRSxHQUFHLEVBQUUsUUFBUTtRQUMzRCxFQUFDLEtBQUssRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsRUFBRSxLQUFLLEVBQUUsQ0FBQyxLQUFLLEVBQUUsR0FBRyxDQUFDLEVBQUMsRUFBRSxNQUFNO0tBQ2pFLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgR29vZ2xlIEluYy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqXG4gKiBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGUgbGljZW5zZSB0aGF0IGNhbiBiZVxuICogZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBhdCBodHRwczovL2FuZ3VsYXIuaW8vbGljZW5zZVxuICovXG5cbi8vIFRISVMgQ09ERSBJUyBHRU5FUkFURUQgLSBETyBOT1QgTU9ESUZZXG4vLyBTZWUgYW5ndWxhci90b29scy9ndWxwLXRhc2tzL2NsZHIvZXh0cmFjdC5qc1xuXG5jb25zdCB1ID0gdW5kZWZpbmVkO1xuXG5mdW5jdGlvbiBwbHVyYWwobjogbnVtYmVyKTogbnVtYmVyIHtcbiAgaWYgKG4gPT09IDEpIHJldHVybiAxO1xuICByZXR1cm4gNTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgW1xuICAncHMnLCBbWyfYui7ZhS4nLCAn2Lou2YguJ10sIHUsIHVdLCB1LFxuICBbXG4gICAgWydTJywgJ00nLCAnVCcsICdXJywgJ1QnLCAnRicsICdTJ10sXG4gICAgWyfZitmI2YbbjScsICfYr9mI2YbbjScsICfYr9ix25DZhtuNJywgJ9qF2YTYsdmG240nLCAn2b7ZitmG2oHZhtuNJywgJ9is2YXYudmHJywgJ9in2YjZhtuNJ10sIHUsXG4gICAgdVxuICBdLFxuICB1LFxuICBbXG4gICAgWyfYrCcsICfZgScsICfZhScsICfYpycsICfZhScsICfYrCcsICfYrCcsICfYpycsICfYsycsICfYpycsICfZhicsICfYryddLFxuICAgIFtcbiAgICAgICfYrNmG2YjYsdmKJywgJ9mB2KjYsdmI2LHZiicsICfZhdin2LHahicsICfYp9m+2LHbjNmEJywgJ9mF240nLCAn2KzZiNmGJywgJ9is2YjZhNin24wnLFxuICAgICAgJ9in2q/Ys9iqJywgJ9iz25DZvtiq2YXYqNixJywgJ9in2qnYqtmI2KjYsScsICfZhtmI2YXYqNixJywgJ9iv2LPZhdio2LEnXG4gICAgXSxcbiAgICB1XG4gIF0sXG4gIFtcbiAgICBbJzEnLCAnMicsICczJywgJzQnLCAnNScsICc2JywgJzcnLCAnOCcsICc5JywgJzEwJywgJzExJywgJzEyJ10sXG4gICAgW1xuICAgICAgJ9is2YbZiNix2YonLCAn2YHYqNix2YjYsdmKJywgJ9mF2KfYsdqGJywgJ9in2b7YsduM2YQnLCAn2YXbjScsICfYrNmI2YYnLCAn2KzZiNmE2KfbjCcsXG4gICAgICAn2Kfar9iz2KonLCAn2LPZvtiq2YXYqNixJywgJ9in2qnYqtmI2KjYsScsICfZhtmI2YXYqNixJywgJ9iv2LPZhdio2LEnXG4gICAgXSxcbiAgICBbXG4gICAgICAn2KzZhtmI2LHZiicsICfZgduQ2KjYsdmI2LHZiicsICfZhdin2LHahicsICfYp9m+2LHbjNmEJywgJ9mF240nLCAn2KzZiNmGJywgJ9is2YjZhNin24wnLFxuICAgICAgJ9in2q/Ys9iqJywgJ9iz2b7YqtmF2KjYsScsICfYp9qp2KrZiNio2LEnLCAn2YbZiNmF2KjYsScsICfYr9iz2YXYqNixJ1xuICAgIF1cbiAgXSxcbiAgW1xuICAgIFsn2YTZhyDZhduM2YTYp9ivINmI2pPYp9mG2K/bkCcsICfZhS4nXSwgdSxcbiAgICBbJ9mE2Ycg2YXbjNmE2KfYryDahdiu2Ycg2Yjak9in2YbYr9uQJywgJ9mE2Ycg2YXbjNmE2KfYryDahdiu2Ycg2YjYsdmI2LPYqtmHJ11cbiAgXSxcbiAgNiwgWzQsIDVdLCBbJ3kvTS9kJywgJ3kgTU1NIGQnLCAn2K8geSDYryBNTU1NIGQnLCAnRUVFRSDYryB5INivIE1NTU0gZCddLFxuICBbJ0g6bW0nLCAnSDptbTpzcycsICdIOm1tOnNzICh6KScsICdIOm1tOnNzICh6enp6KSddLCBbJ3sxfSB7MH0nLCB1LCB1LCB1XSxcbiAgWycsJywgJy4nLCAnOycsICclJywgJ1xcdTIwMGUrJywgJ1xcdTIwMGXiiJInLCAnRScsICfDlycsICfigLAnLCAn4oieJywgJ05hTicsICc6J10sXG4gIFsnIywjIzAuIyMjJywgJyMsIyMwJScsICcjLCMjMC4wMMKgwqQnLCAnI0UwJ10sICfYiycsICfYp9mB2LrYp9mG240nLFxuICB7J0FGTic6IFsn2IsnXSwgJ0pQWSc6IFsnSlDCpScsICfCpSddLCAnVVNEJzogWydVUyQnLCAnJCddfSwgcGx1cmFsXG5dO1xuIl19
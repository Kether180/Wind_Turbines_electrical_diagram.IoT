import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-device-filter-drop-down',
  templateUrl: './device-filter-drop-down.component.html',
  styleUrls: ['./device-filter-drop-down.component.css']
})
export class DeviceFilterDropDownComponent implements OnInit {


  @Output() deviceTypeSelected = new EventEmitter<string>();  // list static define,

  currentDeviceType: string;

  deviceTypeList: string[] = [
    'WEA',
    'CWE',
    'LPC',
    'LMS',
    'ALS',
  ];
  /* devices: DeviceReference[] = [
    {
      id: '4356367800',
      name: '01CWE0001',
    },
    {
      id: '4355144592',
      name: '33WEA00033',
    },
  ]; */


  constructor() { }

  ngOnInit() {
  }
  changeDeviceType(event: any) {
    this.currentDeviceType = (event.target as HTMLSelectElement).value;
    this.deviceTypeSelected.emit(this.currentDeviceType);
  }

}

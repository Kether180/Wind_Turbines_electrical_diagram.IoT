import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeviceFilterDropDownComponent } from './device-filter-drop-down.component';

describe('DeviceFilterDropDownComponent', () => {
  let component: DeviceFilterDropDownComponent;
  let fixture: ComponentFixture<DeviceFilterDropDownComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeviceFilterDropDownComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeviceFilterDropDownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

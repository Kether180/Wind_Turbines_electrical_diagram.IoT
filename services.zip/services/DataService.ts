import { Injectable } from '@angular/core';
import { InventoryService, Realtime, FetchClient, IFetchOptions, IManagedObject } from '@c8y/client';
import { Observable } from 'rxjs';
import { DeviceReference } from '../interfaces/DeviceReference';

@Injectable({
  providedIn: 'root',
})
export class DataService {
  constructor(
    private inventoryService: InventoryService,
    private fetchClient: FetchClient,
    private realtime: Realtime
  ) {
  }

  private getAuthenticationToken(): string {
    return sessionStorage.getItem('_tcy8');
  }

  subscribeToMeasurements$(deviceId: string): Observable<any> {
    return this.realtime.observable(`/measurements/${deviceId}`);
  }

  async getDeviceById(id: string): Promise<IManagedObject> {
    const resp = await this.inventoryService.detail(id);
    return resp.data;
  }

  async getDeviceTypeDescriptionFromDevice(id: string): Promise<string> {
    const mo = await this.getDeviceById(id);
    return `${mo.nx_DeviceTypeDefinition.nx_measurementFragment}`.replace(/^nx_/, '')
  }

  async getDatapointDescription(datapointName: string, deviceType: string): Promise<string> {
    const resp = await this.inventoryService.listQuery({
      name: datapointName,
      deviceType,
    }, {
      pageSize: 1,
    });

    return resp.data[0].c8y_Kpi.description;
  }

  async getDatapointLabel(datapointName: string, deviceType: string): Promise<string> {
    const resp = await this.inventoryService.listQuery({
      name: datapointName,
      deviceType,
    }, {
      pageSize: 1,
    });

    return resp.data[0].c8y_Kpi.label;
  }

  async getDatapointDescriptionWithCustomFetcher(datapointName: string, deviceType: string): Promise<string> {
    const options: IFetchOptions = {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Basic ${this.getAuthenticationToken()}`,
      },
      params: {
        query: `has(c8y_Kpi) and name eq '${datapointName}' and deviceType eq '${deviceType}'`,
        pageSize: 1,
      }
    };

    const resp = await this.fetchClient.fetch('inventory/managedObjects', options);
    const results = await resp.json();
    return results.managedObjects[0].c8y_Kpi.description;
  }

  async getDeviceList(deviceType?: string): Promise<DeviceReference[]> {

    let query = `has(c8y_IsDevice) and type eq 'nx_Unit_*'`;
    if (deviceType) {
      query += ` and nx_DeviceTypeDefinition.nx_measurementFragment eq 'nx_${deviceType}'`;
    }

    const options: IFetchOptions = {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Basic ${this.getAuthenticationToken()}`,
      },
      params: {
        query,
        pageSize: 100,
      }
    };

    const resp = await this.fetchClient.fetch('inventory/managedObjects', options);
    const results = await resp.json();

    return results.managedObjects.map((device) => ({
      id: device.id,
      name: device.name,
    }));
  }
}

import { Injectable } from '@angular/core';
import { DataService } from './DataService';
import { Observable } from 'rxjs';

const CACHE_TYPE_DESCRIPTION = 'description';
const CACHE_TYPE_LABEL = 'label';
const CACHE_TYPE_MEASUREMENTS_REALTIME = 'measurement-subscriptions';

interface CacheResult {
    hit: boolean;
    value: any;
}

@Injectable({
    providedIn: 'root',
})
export class CachedDataService {
    private cache = {
      CACHE_TYPE_DESCRIPTION: {},
      CACHE_TYPE_LABEL: {},
      CACHE_TYPE_MEASUREMENTS_REALTIME: {},
    };
    constructor(private dataService: DataService) {
    }

    private createCacheKey(...keys: string[]): string {
        return keys.join('#');
    }

    private hitCache(type: string, key: string): CacheResult {
        let hit = false;
        let value = null;
        const cache = this.cache[type];
        if (!cache) {
            return {
                hit: false,
                value: null,
            };
        }
        hit = cache.hasOwnProperty(key);

        if (hit) {
            value = cache[key];
        }

        return {
            hit,
            value,
        };
    }

    private setCache(type: string, key: string, value: any) {
        if (!this.cache[type]) {
            this.cache[type] = {};
        }
        this.cache[type][key] = value;
    }

    // clearCache all of the cached values for a particular type
    clearCache(type: string) {
        this.cache[type] = {};
    }

    subscribeToDevice(id: string): Observable<any> {
        const result = this.hitCache(CACHE_TYPE_MEASUREMENTS_REALTIME, id);

        if (result.hit) {
            return result.value;
        }
        const value = this.dataService.subscribeToMeasurements$(id);
        this.setCache(CACHE_TYPE_MEASUREMENTS_REALTIME, id, value);
        return value;
    }

    async getDeviceTypeDescriptionFromDevice(deviceID: string): Promise<string> {
        return this.dataService.getDeviceTypeDescriptionFromDevice(deviceID);
    }

    async getDatapointDescription(datapointName: string, deviceType: string): Promise<string> {
        const cacheKey = this.createCacheKey(deviceType, datapointName);
        const cacheResult = this.hitCache(CACHE_TYPE_DESCRIPTION, cacheKey);
        if (cacheResult.hit) {
            return cacheResult.value;
        }
        const description = await this.dataService.getDatapointDescription(datapointName, deviceType);
        this.setCache(CACHE_TYPE_DESCRIPTION, cacheKey, description);
        return description;
    }

    async getDatapointLabel(datapointName: string, deviceType: string): Promise<string> {
      const cacheKey = this.createCacheKey(deviceType, datapointName);
      const cacheResult = this.hitCache(CACHE_TYPE_LABEL, cacheKey);
      if (cacheResult.hit) {
          return cacheResult.value;
      }
      const label = await this.dataService.getDatapointLabel(datapointName, deviceType);
      this.setCache(CACHE_TYPE_LABEL, cacheKey, label);
      return label;
  }
}

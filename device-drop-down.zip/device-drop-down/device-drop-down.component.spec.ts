import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeviceDropDownComponent } from './device-drop-down.component';

describe('DeviceDropDownComponent', () => {
  let component: DeviceDropDownComponent;
  let fixture: ComponentFixture<DeviceDropDownComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeviceDropDownComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeviceDropDownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

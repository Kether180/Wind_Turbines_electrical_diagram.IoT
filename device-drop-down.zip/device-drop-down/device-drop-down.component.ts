import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { DeviceReference } from '../interfaces/DeviceReference';


@Component({
  selector: 'app-device-drop-down',
  templateUrl: './device-drop-down.component.html',
  styleUrls: ['./device-drop-down.component.css']
})
export class DeviceDropDownComponent implements OnInit {

  selectedDevice: DeviceReference;

  @Input() devices: DeviceReference[];

  @Output() deviceSelected = new EventEmitter<DeviceReference>();

  /* devices: DeviceReference[] = [
    {
      id: '4356367800',
      name: '01CWE0001',
    },
    {
      id: '4355144592',
      name: '33WEA00033',
    },
  ]; */

  constructor() { }

  ngOnInit() {
  }

  changeDevice(event: any) {
    const selectedDeviceID = (event.target as HTMLSelectElement).value;

    this.selectedDevice = this.devices.find((item => item.id === selectedDeviceID));
    console.log(`Selected device:`, this.selectedDevice);
    this.deviceSelected.emit(this.selectedDevice);
  }

}


interface DeviceReference {
  id: string;
  name: string;
  type?: string;
}


export {
    DeviceReference,
};

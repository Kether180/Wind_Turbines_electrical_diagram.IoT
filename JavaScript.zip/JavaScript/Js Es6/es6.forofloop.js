/* or...of loop

The for...of loop is used to loop over any type of data that is iterable.

You write a for...of loop almost exactly like you would write 
a for...in loop, except you swap out in with of and you can drop the index*/

const digits = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];

for (const digit of digits) {
  console.log(digit);
}


// This makes the for...of loop the most concise version of all the for loops.


// But wait, there’s more! The for...of loop also has some additional benefits that fix the weaknesses of the for and for...in loops.

You can stop or break a for...of loop at anytime.


const digits = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];

for (const digit of digits) {
  if (digit % 2 === 0) {
    continue;
  }
  console.log(digit);
}

Prints:
1
3
5
7
9
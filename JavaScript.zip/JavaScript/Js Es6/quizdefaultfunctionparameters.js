/*
 * Programming Quiz: Using Default Function Parameters (2-2)
 */

const buildHouse = ({floors = 1, color = 'red', walls = 'brick'} = {}) => `Your house has ${floors} floor\(s) with ${color} ${walls} walls.`;


console.log(buildHouse());
console.log(buildHouse({}));
console.log(buildHouse({floors: 3, color: 'yellow'}));

/* tests
console.log(buildHouse()); // Your house has 1 floor(s) with red brick walls.
console.log(buildHouse({})); // Your house has 1 floor(s) with red brick walls.
console.log(buildHouse({floors: 3, color: 'yellow'})); // Your house has 3 floor(s) with yellow brick walls.
*/


What Went Well

- Your code should have a function buildHouse()
- Your buildHouse() function should have one parameter
- Your buildHouse() function should accept an object and an empty object as a default parameter
- Your buildHouse() function should set the floors, color, and walls properties to default values
- Your buildHouse() function should produce the correct output when no arguments or any empty object is passed to it
- Your buildHouse() function should produce the correct output when a valid object is passed to it
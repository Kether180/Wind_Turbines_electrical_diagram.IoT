/*
 * Programming Quiz: Writing a For...of Loop (1-4)
 Write a for...of loop that:

    loops through each day in the days array
    capitalizes the first letter of the day
    and prints the day out to the console
    */

 


const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];


for (let day of days) {
    day = day[0].toUpperCase() + day.slice(1);
    console.log(day);
}
/* Static methods

To add a static method, the keyword static is placed in front of the method name. Look at the badWeather() method in the code below */

class Plane {
  constructor(numEngines) {
    this.numEngines = numEngines;
    this.enginesActive = false;
  }

  static badWeather(planes) {
    for (plane of planes) {
      plane.enginesActive = false;
    }
  }

  startEngines() {
    console.log('starting engines…');
    this.enginesActive = true;
  }
}

See how badWeather() has the word static in front of it while startEngines() doesn't? That makes badWeather() a method that's accessed directly on the Plane class, so you can call it like this:

Plane.badWeather([plane1, plane2, plane3]);

    NOTE: A little hazy on how constructor functions, class methods, or prototypal inheritance works? We've got a course on it! Check out Object Oriented JavaScript.



    /* Things to look out for when using classes

    class is not magic
        The class keyword brings with it a lot of mental constructs from other, class-based languages. It doesn't magically add this functionality to JavaScript classes.
    class is a mirage over prototypal inheritance
        We've said this many times before, but under the hood, a JavaScript class just uses prototypal inheritance.
    Using classes requires the use of new
        When creating a new instance of a JavaScript class, the new keyword must be used */


        

// Object Literal Shortland

// If object properties have the same name as the variables being assigned to them, then you can drop the duplicate variable names.


let type = 'quartz';
let color = 'rose';
let carat = 21.29;

const gemstone = {
  type,
  color,
  carat,
  calculateWorth() {
    // will calculate worth of gemstone based on type, color, and carat
  }
};


/* Speaking of shorthand, there’s also a shorthand way to add methods to objects.

To see how that looks, let’s start by adding a calculateWorth() method to our gemstone object.
The calculateWorth() method will tell us how much our gemstone costs based on its type, color, and carat. */


// we have learnt , how to declare variables : let & const , template literals , destructuring, object literal shorthand.
var  price = 15.00 // price
var  money = 20.00 // How much does the hammer cost
if (money >= price){
    console.log("buy the hammer");
}else{ 
console.log("don't buy the hammer");
}
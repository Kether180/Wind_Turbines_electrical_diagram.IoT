var colt = "not busy";
var weather = "nice";

if (colt === "not busy" && weather === "nice") { // && Returns true if both value1 and value2 evaluate to true.
  console.log("go to the park");
}
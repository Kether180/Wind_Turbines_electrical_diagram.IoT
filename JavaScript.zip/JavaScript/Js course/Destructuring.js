const point = [10, 25, -34];

const x = point[0];
const y = point[1];
const z = point[2];

console.log(x, y, z);

// Prints: 10 25 -34



/* And this example shows extracting values from an object.

Both are pretty straightforward, however, neither of these examples are actually using destructuring.

So what exactly is destructuring? */




const gemstone = {
  type: 'quartz',
  color: 'rose',
  carat: 21.29
};

const type = gemstone.type;
const color = gemstone.color;
const carat = gemstone.carat;

console.log(type, color, carat);

// rints: quartz rose 21.29

// In this example, the curly braces { } represent the object being destructured and type, color, and carat represent the variables where you want to store the properties from the object.

TIP: You can also specify the values you want to select when destructuring an object. For example, let {color} = gemstone; will only select the color property from the gemstone object.


Destructuring values from an array

const point = [10, 25, -34];

const [x, y, z] = point;
 
console.log(x, y, z);     // Prints: 10 25 -34    TIP: You can also ignore values when destructuring arrays. For example, const [x, , z] = point; ignores the y coordinate and discards it.


//// /  What do you expect to be returned from calling getArea()?


const circle = {
    radius: 10,
    color: 'orange',
    getArea: function() {
      return Math.PI * this.radius * this.radius;
    },
    getCircumference: function() {
      return 2 * Math.PI * this.radius;
    }
  };
  
  let {radius, getArea, getCircumference} = circle; // getArea is destructured and stored in the getArea() mehtod it not longer has acce


  // Correct! Calling getArea() will return NaN. 
  // When you destructure the object and store the getArea() method into the getArea variable, it no longer has access to this in the circle object which results in an area that is NaN.
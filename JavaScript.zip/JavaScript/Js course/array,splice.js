var donuts = ["glazed", "chocolate frosted", "Boston creme", "glazed cruller"];
donuts.splice(1, 1, "chocolate cruller", "creme de leche"); // removes "chocolate frosted" at index 1 and adds "chocolate cruller" and "creme de leche" starting at index 1

Returns: ["chocolate frosted"]
donuts array: ["glazed", "chocolate cruller", "creme de leche", "Boston creme", "glazed cruller"]


// We’ve decided to replace some of the donuts in the donuts array.

var donuts = ["cookies", "cinnamon sugar", "creme de leche"];

donuts.splice(-2, 0, "chocolate frosted", "glazed");

// What does the donuts array look like after the following changes?

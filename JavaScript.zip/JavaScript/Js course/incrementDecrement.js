/*
 * Programming Quiz: Changing the Loop (4-4)
 */

// rewrite the while loop as a for loop
/*var x = 9;
while (x >= 1) {
    console.log("hello " + x);
    x = x - 1;
}
*/

for ( var x = 9 ; x >= 1; x--) {
    console.log("hello " + x);
    
  }


//x++ or ++x // same as x = x + 1 
//x-- or --x // same as x = x - 1
//x += 3 // same as x = x + 3
//x -= 6 // same as x = x - 6
//x *= 2 // same as x = x * 2
//x /= 5 // same as x = x / 5


/*
 * Programming Quiz: Fix the Error 1 (4-5)
 */

// Here is a for loop that's supposed to print the numbers 5 through 9. Fix the error!

// fix the for loop

/*  for (x < 10; x++) {
   console.log(x);
  } */
  
  for (var x = 5 ; x < 10; x++) {
    console.log(x);
}



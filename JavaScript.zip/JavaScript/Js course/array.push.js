var donuts = ["glazed", "chocolate frosted", "Boston creme", "glazed cruller", "cinnamon sugar", "sprinkled"];

donuts.push("powdered"); // pushes "powdered" onto the end of the `donuts` array

// the `push()` method returns 7 because the `donuts` array now has 7 elements
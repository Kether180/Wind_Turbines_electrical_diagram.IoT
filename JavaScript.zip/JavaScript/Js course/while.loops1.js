/*
 * Programming Quiz: JuliaJames (4-1)
 */

var x = 1;

while (x <= 20 /* your stop condition goes here */) {
    // check divisibility 
    if ((x % 3 === 0) && (x % 5 === 0)){  // // if a number is divisible by another number  x % y === 0.
        console.log("JuliaJames");
    } 
    else if (x % 3 === 0){ 
        console.log("Julia");
    } 
    else if (x % 5 === 0){ 
        console.log("James");
    } 

    else { 
        console.log(x);
    }
    // print Julia, James, or JuliaJames
    // increment x 
    x = x + 1;
}
//Loop through the numbers 1 to 20
// If the number is divisible by 3, print "Julia"
// If the number is divisible by 5, print "James"
// If the number is divisible by 3 and 5, print "JuliaJames"
// If the number is not divisible by 3 or 5, print the number


// TIP: A number x is divisible by a number y if the answer to x / y has a remainder of 0. 
// For example, 10 is divisible by 2 because 10 / 2 = 5 with no remainder.
//  You can check if a number is divisible by another number by checking if x % y === 0.

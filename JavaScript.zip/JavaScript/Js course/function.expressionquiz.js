/* Directions:

Write a named function expression that stores the function in a variable called cry and returns 
"boohoo!". Don't forget to call the function using the variable name, not the function name:

cry();

    Returns: boohoo! */






var cry = function createCry(){
cryString = "boohoo!";
return cryString;
};
console.log(cry());
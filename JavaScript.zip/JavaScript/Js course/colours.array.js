
var rainbow = ['Red', 'Orange', 'Blackberry', 'Blue'];

// your code goes here

//Inclui a partir da posição 2, exclui 1.
rainbow.splice(2, 1, "Yellow", "Green");
//Inclui a partir da ultima posição do array, exclui 0.
rainbow.splice(rainbow.length, 0, "Purple");
console.log(rainbow);
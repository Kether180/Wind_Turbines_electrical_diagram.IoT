/*
 * Instructions: Change the `greeting` string to use a template literal.
 */

const myName = '[Pedro]';
const greeting = 'Hello, my name is ${myName}';
console.log(greeting);


...but what about the multi-line example from before?

let note = teacher.name + ',\n\n' +
  'Please excuse ' + student.name + '.\n' +
  'He is recovering from the flu.\n\n' +
  'Thank you,\n' +
  student.guardian;
  
  becomes,

  
  var note = `${teacher.name},

  Please excuse ${student.name}.
  He is recovering from the flu.

  Thank you,
  ${student.guardian}`;
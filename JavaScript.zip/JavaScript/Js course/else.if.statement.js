var weather = "sunny";

if (weather === "snow") {
  console.log("Bring a coat.");
} else if (weather === "rain") {
  console.log("Bring a rain jacket.");
} else {
  console.log("Wear what you have on.");
}


//In JavaScript, you can represent this secondary
// check by using an extra if statement called an else if statement.

/* Prints: Wear what you have on*/ 

/* By adding the extra else if statement,
 you're adding an extra conditional statement. */
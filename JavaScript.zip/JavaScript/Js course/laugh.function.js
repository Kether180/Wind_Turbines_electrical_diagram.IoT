function laugh() {
    
 return "hahahahahahahahahaha!";
    
}
    
console.log(laugh());
    
    
 // Directions: Declare a function called laugh() that returns "hahahahahahahahahaha!".
 // Print the value returned from the laugh() function to the console.
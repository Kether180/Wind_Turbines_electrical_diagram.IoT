var myObj = { 
  color: "orange",
  shape: "sphere",
  type: "food",
  eat: function() { return "yummy" }
};

myObj.eat(); // method
myObj.color; // property


var breakfast = {
    name:"The Lumberjack",
    price: "$9.95",
    ingredients: ["eggs","sausage","toast","hashbrowns","pancakes"]
};

    console.log(breakfast.name);  
    console.log(breakfast.price);
    console.log(breakfast.ingredients);
      

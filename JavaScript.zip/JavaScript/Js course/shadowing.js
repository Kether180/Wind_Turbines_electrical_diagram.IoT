/* Question 1 of 2 */ 

// Without pasting into your console, what do you think this code will print out?

var x = 1;

function addTwo() {
  x = x + 2;
}

addTwo();
x = x + 1;
console.log(x);

// 4 


/* Question 2 of 2 */

// Without pasting into your console, what do you think this code will print out?

var x = 1;

function addTwo() {
  var x = x + 2;   // will print 2 , The variable assignment inside the function addTwo() 
  // only has function scope, so its affect is not reflected outside the function, it will print
  // the following fuction and not the actual one.  
}

addTwo();
x = x + 1;
console.log(x);

// 2 
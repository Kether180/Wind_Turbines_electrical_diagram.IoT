var number = 2;

if (number % 2 === 0) {

    console.log("even");

} else {

    console.log("odd");

}

// even
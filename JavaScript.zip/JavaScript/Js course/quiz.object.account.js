var savingsAccount = {
    balance : 1000,
    interestRatePercent: 1,
    deposit: function addMoney(amount) {

        if (amount > 0) {
            savingsAccount.balance += amount;

        }

    },

    withdraw: function removeMoney(amount) {

        var verifyBalance = savingsAccount.balance - amount;
        if ( amount > 0 && verifyBalance >= 0) {

            savingsAccount.balance -= amount;
        }
    },

    printAccountSummary:function printAccountSummary() { 
    return "Welcome!\n" + "Your balance is currently $" +  savingsAccount.balance + " and your interest rate is " + savingsAccount.interestRatePercent +  "%."
}

};

console.log(savingsAccount.printAccountSummary());



/* Quiz-4
Which of the following are valid ways to access properties and call methods from the savingsAccount object?

Answer:
1. savingAccount.balance;   // using dot notation
2. savingAccount["balance"];   // using bracket notation
3. savingsAccount.withdraw(50); */ 
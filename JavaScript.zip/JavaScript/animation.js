


  /* Animation switch on/off lamps*/


var switcherOn = $('.switch--on');
  var switcherOff = $('.switch--off');

  switcherOn.show();
  switcherOff.hide();

  switcherOn.click(function() {
    lamps.play();
    switcherOn.toggle();
    switcherOff.toggle();
  });

  switcherOff.click(function() {
    lamps.reverse(-3);
    switcherOn.toggle();
    switcherOff.toggle();
  });

 /* Animation des lampes */

  var lamps = new TimelineMax();
  var light = $('polygon.light');

  lamps.pause();

  lamps.from(light, 0.5, {
      opacity: 0,
    })
    .to(light, 2.5, {
      opacity: 1
    });


https://envato.com/blog/snippets-canvas-svg/



/*  *ngFor
*ngFor is a "structural directive". Structural directives shape or reshape the DOM's structure(Document Object Model), typically by adding,
 removing, and manipulating the elements to which they are attached. Any directive with an asterisk, *, is a structural directive. */


 https://angular.io/start
 
 /* Interpolation {{ }} 
 
 To display the names of the products, use the interpolation syntax {{ }}.
  Interpolation renders a property's value as text. Inside the <div>, add an <h3> to display the interpolation of the product's name property: */


 /*    Property binding [ ]
 
 To make each product name a link to product details, add the <a> element and set its title to be the product's name by using the property binding [ ] syntax, as follows */

 /* Add the product descriptions. On the <p> element, use an *ngIf directive so that Angular only creates the <p> element if the current product has a description. */

 /* The app now displays the name and description of each product in the list. Notice that the final product does not have a description paragraph.
  Because the product's description property is empty, Angular doesn't create the <p> element—including the word "Description".*/

  /* Add a button so users can share a product with friends. Bind the button's click event to the share() method (in product-list.component.ts). 
  Event binding uses a set of parentheses, ( ), around the event, as in the following <button> element: */ 

  /* 5 common Angular's template features 

  The app now has a product list and sharing feature. In the process, you've learned to use five common features of Angular's template syntax:

    *ngFor
    *ngIf
    Interpolation {{ }}
    Property binding [ ]
    Event binding ( )  

    For more information about the full capabilities of Angular's template syntax, see Template Syntax.   https://angular.io/guide/template-syntax

    // Components

Components define areas of responsibility in the user interface, or UI, that let you reuse sets of UI functionality. You've already built one with the product list component.

A component consists of three things:

    A component class
     that handles data and functionality. In the previous section, the product data and the share() method in the component class handle data and functionality, respectively.

    An HTML template

    Determines the UI. In the previous section, the product list's HTML template displays the name, description, and a "Share" button for each product.

    Component-specific styles 
    Define the look and feel. Though product list does not define any styles, this is where component CSS resides.

An Angular application comprises a tree of components, in which each Angular component has a specific purpose and responsibility.

Currently, the example app has three components: 



app-root (orange box) is the application shell. This is the first component to load and the parent of all other components. You can think of it as the base page.

app-top-bar (blue background) is the store name and checkout button.

app-product-list (purple box) is the product list that you modified in the previous section.

The next section expands the app's capabilities by adding a new component—a product alert—as a child of the product list component.

For more information about components and how they interact with templates, see Introduction to Components. https://angular.io/guide/architecture-components



// Input

Currently, the product list displays the name and description of each product. The product list component also defines a products property that contains imported data for each product from the products array in products.ts.

The next step is to create a new alert feature that takes a product as an input. The alert checks the product's price, and, if the price is greater than $700, displays a "Notify Me" button that lets users sign up for notifications when the product goes on sale.

    Create a new product alerts component.

        Right click on the app folder and use the Angular Generator to generate a new component named product-alerts.


        The generator creates starter files for all three parts of the component:
        product-alerts.component.ts
        product-alerts.component.html
        product-alerts.component.css

2 . Open product-alerts.component.ts.



Notice the @Component() decorator. This indicates that the following class is a component. It provides metadata about the component, including its selector, templates, and styles.

The selector identifies the component. The selector is the name you give the Angular component when it is rendered as an HTML element on the page. By convention, Angular component selectors begin with the prefix app-, followed by the component name.

The template and style filenames reference the HTML and CSS files that StackBlitz generates.

The component definition also exports the class, ProductAlertsComponent, which handles functionality for the component.

Set up the new product alerts component to receive a product as input:

Import Input from @angular/core.


------ Set up the new product alerts component to receive a product as input:

a . Import Input from @angular/core. 

import { Component, OnInit } from '@angular/core';
import { Input } from '@angular/core';



b. In the ProductAlertsComponent class definition, 
define a property named product with an @Input() decorator. The @Input() decorator indicates that the property value passes in from the component's parent, the product list component 

@Input() product;


4 Define the view for the new product alert component.

    Open the product-alerts.component.html template and replace the placeholder paragraph with a "Notify Me" button that appears if the product price is over $700.


    <p *ngIf="product.price > 700">
  <button>Notify Me</button>
</p>


5. Display the new product alert component as a child of the product list.

Open product-list.component.html.

To include the new component, use its selector, app-product-alert, as you would an HTML element.

Pass the current product as input to the component using property binding.
src/app/product-list/product-list.component.html

      

<button (click)="share()">
Share
</button>

<app-product-alerts
[product]="product">
</app-product-alerts>

See Component Interaction for more information about passing data from a parent to child component,
 intercepting and acting upon a value from the parent, and detecting and acting on changes to input property values. https://angular.io/guide/component-interaction


 Output

To make the "Notify Me" button work, you need to configure two things:

    the product alert component to emit an event when the user clicks "Notify Me"
    the product list component to act on that event

    Open product-alerts.component.ts.

    Import Output and EventEmitter from @angular/core:


     // Next, define the behavior that should happen when the user clicks the button. Recall that it's the parent,
     //  product list component—not the product alerts component—that's acts when the child raises the event. In product-list.component.ts, define an onNotify() method, similar to the share() method:


     onNotify() {
        window.alert('You will be notified when the product goes on sale');


      }
    }

   6.  Finally, update the product list component to receive output from the product alerts component.

In product-list.component.html, bind the app-product-alerts component (which is what displays the "Notify Me" button) to the onNotify() method of the product list component.


<button (click)="share()">
  Share
</button>

<app-product-alerts
  [product]="product" 
  (notify)="onNotify()">
</app-product-alerts>

*/